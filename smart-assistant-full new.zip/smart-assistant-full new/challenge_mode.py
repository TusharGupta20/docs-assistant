
import google.generativeai as genai
from config import GOOGLE_API_KEY

genai.configure(api_key=GOOGLE_API_KEY)
model = genai.GenerativeModel("models/gemini-2.0-flash")

def generate_questions(text):
    prompt = f"Generate 3 logic-based comprehension questions from the following text:\n{text}"
    response = model.generate_content(prompt)
    return response.text.strip().split("\n")

def evaluate_answer(question, answer, reference):
    prompt = f'''
Evaluate the user's answer against the reference.

Question: {question}
User's Answer: {answer}
Reference Context: {reference}

Rate from 1 to 10 and justify the score.
'''
    response = model.generate_content(prompt)
    return response.text.strip()
