import streamlit as st
from document_parser import extract_text
from summarizer import generate_summary
from rag_engine import embed_and_store, answer_question
from challenge_mode import generate_questions, evaluate_answer
import time
from concurrent.futures import ThreadPoolExecutor
import asyncio

# Set page config
st.set_page_config(
    page_title="DocuLens - Intelligent Document Assistant",
    page_icon="🔍",
    layout="centered",
    initial_sidebar_state="expanded"
)

# Custom CSS for styling and animations
st.markdown("""
    <style>
        .stApp {
            max-width: 1200px;
            margin: 0 auto;
            transition: all 0.3s ease;
        }
        .stButton > button {
            width: 100%;
            border-radius: 8px;
            padding: 0.5rem 1rem;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .stButton > button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .stTextInput > div > div > input {
            border-radius: 8px;
            padding: 0.5rem 1rem;
        }
        .stMarkdown {
            line-height: 1.6;
        }
        .fade-in {
            animation: fadeIn 0.5s;
        }
        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }
        @media (max-width: 768px) {
            .stApp {
                padding: 1rem;
            }
        }
    </style>
""", unsafe_allow_html=True)

# Cache expensive operations with longer expiration
@st.cache_data(ttl=3600, max_entries=10, show_spinner=False)
def cached_extract_text(file):
    return extract_text(file)

@st.cache_data(ttl=3600, max_entries=10, show_spinner=False)
def cached_generate_summary(text):
    return generate_summary(text)

async def process_document_async(uploaded):
    start_time = time.time()
    with ThreadPoolExecutor(max_workers=4) as executor:
        loop = asyncio.get_event_loop()
        
        # Initialize progress tracking
        progress = st.progress(0)
        status_text = st.empty()
        
        # Run operations in parallel
        status_text.text("Extracting text... (Estimated: 2-5 seconds)")
        text_future = loop.run_in_executor(executor, cached_extract_text, uploaded)
        text = await text_future
        progress.progress(25)
        
        # Run embedding and summary in parallel
        status_text.text("Processing document... (Estimated: 5-10 seconds)")
        embed_future = loop.run_in_executor(executor, embed_and_store, text)
        summary_future = loop.run_in_executor(executor, cached_generate_summary, text)
        
        # Wait for both to complete
        await asyncio.gather(embed_future, summary_future)
        summary = summary_future.result()
        progress.progress(100)
        
        # Clear progress indicators
        progress.empty()
        status_text.empty()
        
        return text, summary, time.time() - start_time

# Sidebar for navigation and settings
with st.sidebar:
    st.title("⚙️ Settings")
    theme = st.selectbox("Theme", ["Light", "Dark"], index=0)
    st.session_state['theme'] = theme
    
    st.markdown("---")
    st.markdown("💬 Feedback")
    feedback = st.text_area("Your feedback helps us improve!")
    if st.button("Submit Feedback"):
        # TODO: Implement feedback storage
        st.success("Thank you for your feedback!")

# Apply theme based on selection
if st.session_state.get('theme') == "Dark":
    st.markdown("""
        <style>
            .stApp {
                background-color: #0E1117;
                color: #FAFAFA;
            }
            .stTextInput > div > div > input {
                background-color: #262730;
                color: #FAFAFA;
            }
            .stButton > button {
                background-color: #4F8BF9;
                color: white;
            }
        </style>
    """, unsafe_allow_html=True)
else:
    st.markdown("""
        <style>
            .stApp {
                background-color: #FFFFFF;
                color: #000000;
            }
            .stTextInput > div > div > input {
                background-color: #FFFFFF;
                color: #000000;
            }
            .stButton > button {
                background-color: #F0F0F0;
                color: #000000;
            }
        </style>
    """, unsafe_allow_html=True)

# Main content
st.title("🧠 Smart Research Assistant")
st.markdown("Your AI-powered research companion")

# File upload section
with st.expander("📁 Upload Document", expanded=True):
    uploaded = st.file_uploader("Upload PDF or TXT", type=["pdf", "txt"], label_visibility="collapsed")
    if uploaded:
        with st.spinner("Processing your document... (Estimated: 7-15 seconds)"):
            start_time = time.time()
            
            # Process document asynchronously
            try:
                text, summary, processing_time = asyncio.run(process_document_async(uploaded))
            except Exception as e:
                st.error(f"Error processing document: {str(e)}")
                st.stop()
            
            st.subheader("📄 Summary")
            with st.container():
                st.markdown(summary, unsafe_allow_html=True)
                if st.button("✨ Elaborate Summary"):
                    with st.spinner("Generating detailed summary... (Estimated: 3-5 seconds)"):
                        detailed_summary = cached_generate_summary(summary)
                        st.markdown(detailed_summary, unsafe_allow_html=True)
            
            st.info(f"Processing completed in {processing_time:.2f} seconds")

# Question answering section
st.subheader("🤖 Ask Anything")
query = st.text_input("Enter your question here...", placeholder="Ask me anything about the document")
if query:
    with st.spinner("Generating answer... (Estimated: 2-3 seconds)"):
        response = answer_question(query)
        with st.container():
            st.markdown(f"**Answer:**\n{response}", unsafe_allow_html=True)
            if st.button("✨ Elaborate Answer"):
                with st.spinner("Generating detailed answer... (Estimated: 3-5 seconds)"):
                    detailed_response = answer_question(f"Elaborate on: {response}")
                    st.markdown(detailed_response, unsafe_allow_html=True)

# Challenge mode section
st.subheader("🧩 Challenge Me")
if st.button("Generate Questions"):
    with st.spinner("Creating questions... (Estimated: 3-5 seconds)"):
        questions = generate_questions(text)
        for i, q in enumerate(questions, 1):
            with st.container():
                st.markdown(f"### Question {i}")
                st.markdown(q)
                user_input = st.text_input(f"Your answer to Q{i}", key=f"q{i}")
                if user_input:
                    with st.spinner("Evaluating your answer... (Estimated: 2-3 seconds)"):
                        context = answer_question(q)
                        result = evaluate_answer(q, user_input, context)
                        st.markdown(f"**Evaluation:**\n{result}", unsafe_allow_html=True)
                        if st.button(f"✨ Elaborate Evaluation {i}"):
                            with st.spinner("Generating detailed evaluation... (Estimated: 3-5 seconds)"):
                                detailed_eval = evaluate_answer(q, user_input, context, detailed=True)
                                st.markdown(detailed_eval, unsafe_allow_html=True)