import os
from dotenv import load_dotenv
load_dotenv()

# Use direct API key as fallback if not in .env
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "AIzaSyB8cdDJMjmeLbmQRco8h4jwYAW2Af5SCUo")