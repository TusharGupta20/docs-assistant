
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import google.generativeai as genai
from config import GOOGLE_API_KEY

genai.configure(api_key=GOOGLE_API_KEY)
model = genai.GenerativeModel("models/gemini-2.0-flash")
embedder = SentenceTransformer("all-MiniLM-L6-v2")

index = None
chunks = []

def embed_and_store(text, chunk_size=500):
    global index, chunks
    chunks = [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]
    embeddings = embedder.encode(chunks)
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(np.array(embeddings))

def get_top_k_chunks(query, k=3):
    q_embed = embedder.encode([query])
    D, I = index.search(np.array(q_embed), k)
    return [chunks[i] for i in I[0]]

def answer_question(query):
    context = get_top_k_chunks(query)
    prompt = f'''You are a research assistant. Use the document context below to answer the question.

Question: {query}
Context:
{chr(10).join(context)}

Provide a clear, referenced answer.'''
    response = model.generate_content(prompt)
    return response.text.strip()
